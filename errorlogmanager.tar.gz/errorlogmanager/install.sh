#!/bin/bash
# WHM Error Log Manager - Install Script

set -euo pipefail

PLUGIN_NAME="errorlogmanager"
WHM_CGI="/usr/local/cpanel/whostmgr/docroot/cgi"
WHM_ADDONS="/usr/local/cpanel/whostmgr/docroot/addon_plugins"
APPCONFIG_DIR="/var/cpanel/apps"
PLUGIN_DIR="${WHM_CGI}/${PLUGIN_NAME}"
APPCONFIG_CONF="${APPCONFIG_DIR}/${PLUGIN_NAME}.conf"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] Must be run as root."
    exit 1
fi

if [[ ! -d "$WHM_CGI" ]]; then
    echo "[ERROR] WHM CGI directory not found: ${WHM_CGI}"
    exit 1
fi

if [[ ! -x "/usr/local/cpanel/bin/register_appconfig" ]]; then
    echo "[ERROR] register_appconfig not found."
    exit 1
fi

echo ""
echo "  WHM Error Log Manager - Installer"
echo "  ───────────────────────────────────"
echo ""

echo "[1/5] Creating plugin directory..."
mkdir -p "${PLUGIN_DIR}/assets"

echo "[2/5] Copying plugin files..."
cp "${SCRIPT_DIR}/errorlogmanager.cgi" "${PLUGIN_DIR}/errorlogmanager.cgi"
cp "${SCRIPT_DIR}/assets/app.js"       "${PLUGIN_DIR}/assets/app.js"

echo "[3/5] Setting permissions..."
chown -R root:root "${PLUGIN_DIR}"
chmod 755 "${PLUGIN_DIR}"
chmod 755 "${PLUGIN_DIR}/assets"
chmod 755 "${PLUGIN_DIR}/errorlogmanager.cgi"
chmod 644 "${PLUGIN_DIR}/assets/app.js"

echo "[4/5] Installing AppConfig conf and icon..."
mkdir -p "${APPCONFIG_DIR}"
cp "${SCRIPT_DIR}/errorlogmanager.conf" "${APPCONFIG_CONF}"
chmod 644 "${APPCONFIG_CONF}"
mkdir -p "${WHM_ADDONS}"
printf '\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4\x89\x00\x00\x00\nIDATx\x9cc\x00\x01\x00\x00\x05\x00\x01\r\n-\xb4\x00\x00\x00\x00IEND\xaeB`\x82' \
    > "${WHM_ADDONS}/${PLUGIN_NAME}.png"

echo "[5/5] Registering with WHM AppConfig..."
/usr/local/cpanel/bin/register_appconfig "${APPCONFIG_CONF}"

echo ""
echo "  ✓ Done. Go to WHM → Plugins → Error Log Manager"
echo ""
