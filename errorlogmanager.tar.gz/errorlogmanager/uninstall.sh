#!/bin/bash
# WHM Error Log Manager - Uninstall Script

set -euo pipefail

PLUGIN_NAME="errorlogmanager"
WHM_CGI="/usr/local/cpanel/whostmgr/docroot/cgi"
WHM_ADDONS="/usr/local/cpanel/whostmgr/docroot/addon_plugins"
APPCONFIG_DIR="/var/cpanel/apps"
PLUGIN_DIR="${WHM_CGI}/${PLUGIN_NAME}"
APPCONFIG_CONF="${APPCONFIG_DIR}/${PLUGIN_NAME}.conf"
SOURCE_DIR="/usr/src/${PLUGIN_NAME}"
SOURCE_TAR="/usr/src/${PLUGIN_NAME}.tar.gz"

if [[ $EUID -ne 0 ]]; then
    echo "[ERROR] Must be run as root."
    exit 1
fi

echo ""
echo "  WHM Error Log Manager - Uninstaller"
echo "  ─────────────────────────────────────"
echo ""

read -rp "  Remove everything? [y/N] " confirm
if [[ ! "$confirm" =~ ^[Yy]$ ]]; then
    echo "  Aborted."
    exit 0
fi

echo ""

echo "[1/5] Unregistering from WHM AppConfig..."
if [[ -x "/usr/local/cpanel/bin/unregister_appconfig" ]]; then
    /usr/local/cpanel/bin/unregister_appconfig "${PLUGIN_NAME}" 2>/dev/null && echo "  Unregistered." || echo "  Not registered, skipping."
else
    echo "  unregister_appconfig not found, skipping."
fi

echo "[2/5] Removing plugin directory..."
[[ -d "$PLUGIN_DIR" ]] && rm -rf "$PLUGIN_DIR" && echo "  Removed: ${PLUGIN_DIR}" || echo "  Not found, skipping."

echo "[3/5] Removing AppConfig conf..."
[[ -f "$APPCONFIG_CONF" ]] && rm -f "$APPCONFIG_CONF" && echo "  Removed: ${APPCONFIG_CONF}" || echo "  Not found, skipping."

echo "[4/5] Removing icon..."
[[ -f "${WHM_ADDONS}/${PLUGIN_NAME}.png" ]] && rm -f "${WHM_ADDONS}/${PLUGIN_NAME}.png" && echo "  Removed." || echo "  Not found, skipping."

echo "[5/5] Removing source files..."
[[ -d "$SOURCE_DIR" ]] && rm -rf "$SOURCE_DIR" && echo "  Removed: ${SOURCE_DIR}" || echo "  Not found, skipping."
[[ -f "$SOURCE_TAR" ]] && rm -f  "$SOURCE_TAR" && echo "  Removed: ${SOURCE_TAR}" || echo "  Not found, skipping."

echo ""
echo "  ✓ Uninstall complete."
echo ""
