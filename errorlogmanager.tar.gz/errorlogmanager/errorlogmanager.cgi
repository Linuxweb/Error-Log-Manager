#!/usr/local/cpanel/3rdparty/bin/perl
#WHMADDON:errorlogmanager:Error Log Manager
use strict;
use warnings;
use Whostmgr::ACLS          ();
use Whostmgr::HTMLInterface ();
use Cpanel::Form            ();
use JSON::XS                ();
use Cwd                     'abs_path';

Whostmgr::ACLS::init_acls();

my %FORM   = Cpanel::Form::parseform();
my $action = $FORM{'action'} || '';

# ── API HANDLER ───────────────────────────────────────────────────────────────
if ($action) {
    print "Content-Type: application/json\r\n\r\n";

    # LOAD
    if ($action eq 'load') {
        open(my $fh, '<', '/proc/loadavg') or die "Cannot read loadavg: $!";
        my $line = <$fh>;
        close $fh;
        my @load = split /\s+/, $line;
        print JSON::XS->new->encode({
            load_1  => $load[0]+0,
            load_5  => $load[1]+0,
            load_15 => $load[2]+0,
        });
        exit;
    }

    # AUTODETECT
    if ($action eq 'autodetect') {
        my $mode   = 'legacy';
        my $reason = 'No FPM logs found in /home/*/logs/';
        my $cse    = (-f '/var/cpanel/apps/cse.conf') ? JSON::XS::true() : JSON::XS::false();

        my @pools = glob('/opt/cpanel/ea-php*/root/etc/php-fpm.d/*.conf');
        if (@pools) {
            $mode   = 'fpm';
            $reason = 'EA-PHP FPM pool configs detected';
        } else {
            my @logs = glob('/home/*/logs/*.php.error.log');
            if (@logs) {
                $mode   = 'fpm';
                $reason = 'PHP FPM error logs found in /home/*/logs/';
            }
        }
        print JSON::XS->new->encode({ mode => $mode, reason => $reason, cse => $cse });
        exit;
    }

    # SCAN
    if ($action eq 'scan') {
        my $mode     = $FORM{'mode'} || 'fpm';
        my $age_days = int($FORM{'age_days'} || 5);
        $age_days    = 1 if $age_days < 1;
        my $cutoff   = time() - ($age_days * 86400);

        my @skip     = qw(nobody mail ftp cpanel root virtfs);
        my %skip_map = map { $_ => 1 } @skip;

        # Build domain map from /etc/userdatadomains
        my %domain_map;
        if (open(my $fh, '<', '/etc/userdatadomains')) {
            while (my $line = <$fh>) {
                chomp $line;
                my ($domain) = split /:/, $line, 2;
                next unless $domain;
                $domain = lc(trim($domain));
                my $key = $domain;
                $key =~ s/[\.\-]/_/g;
                $domain_map{$key} = $domain;
            }
            close $fh;
        }

        my @results;

        if ($mode eq 'fpm') {
            for my $logs_dir (glob('/home/*/logs')) {
                next unless -d $logs_dir;
                my ($username) = $logs_dir =~ m{^/home/([^/]+)/logs$} or next;
                next if $skip_map{$username};

                for my $filepath (glob("$logs_dir/*.php.error.log")) {
                    next unless -f $filepath && !-l $filepath;
                    my $filename        = (split '/', $filepath)[-1];
                    my $domain          = match_domain($filename, \%domain_map);
                    my @st              = stat($filepath);
                    my $mtime           = $st[9] || 0;
                    my $size            = $st[7] || 0;
                    my $age_days_actual = int((time() - $mtime) / 86400);
                    push @results, {
                        user        => $username,
                        domain      => $domain,
                        file        => $filename,
                        path        => $filepath,
                        rel_path    => '',
                        size        => $size,
                        size_human  => format_bytes($size),
                        mtime       => $mtime,
                        mtime_human => format_date($mtime),
                        age_days    => $age_days_actual,
                        candidate   => ($mtime < $cutoff) ? JSON::XS::true() : JSON::XS::false(),
                        mode        => 'fpm',
                    };
                }
            }

        } else {
            # Legacy mode
            for my $home_dir (glob('/home/*')) {
                next unless -d $home_dir;
                my ($username) = $home_dir =~ m{^/home/([^/]+)$} or next;
                next if $skip_map{$username};
                my $pub = "$home_dir/public_html";
                next unless -d $pub;

                for my $filepath (find_error_logs($pub)) {
                    next unless -f $filepath && !-l $filepath;
                    my @st              = stat($filepath);
                    my $mtime           = $st[9] || 0;
                    my $size            = $st[7] || 0;
                    my $age_days_actual = int((time() - $mtime) / 86400);

                    # Full relative path from public_html for display
                    my $rel = $filepath;
                    $rel =~ s{^\Q$pub\E/?}{};
                    my @parts  = split '/', $rel;
                    my $domain = @parts > 1 ? $parts[0] : $username;
                    # Parent directory for CSE link
                    my $parent_dir = $filepath;
                    $parent_dir    =~ s{/[^/]+$}{};

                    push @results, {
                        user        => $username,
                        domain      => $domain,
                        file        => 'error_log',
                        path        => $filepath,
                        rel_path    => $rel,
                        parent_dir  => $parent_dir,
                        size        => $size,
                        size_human  => format_bytes($size),
                        mtime       => $mtime,
                        mtime_human => format_date($mtime),
                        age_days    => $age_days_actual,
                        candidate   => JSON::XS::true(),
                        mode        => 'legacy',
                    };
                }
            }
        }

        @results = sort { $a->{user} cmp $b->{user} || $a->{domain} cmp $b->{domain} } @results;
        print JSON::XS->new->encode({ files => \@results, summary => build_summary(\@results) });
        exit;
    }

    # DELETE
    if ($action eq 'delete') {
        my $paths_val = $FORM{'paths'};
        my @paths;
        if    (ref $paths_val eq 'ARRAY') { @paths = grep { $_ } @$paths_val; }
        elsif ($paths_val)                { @paths = ($paths_val); }

        if (!@paths) {
            print JSON::XS->new->encode({ results => [], error => 'No paths received' });
            exit;
        }

        my $mode    = $FORM{'mode'} || 'fpm';
        my @results;

        for my $path (@paths) {
            next unless $path;
            my $safe = sanitise_path($path, $mode);
            unless ($safe) {
                push @results, { path => $path, success => JSON::XS::false(), message => 'Invalid or unsafe path' };
                next;
            }
            unless (-f $safe) {
                push @results, { path => $safe, success => JSON::XS::false(), message => 'File not found' };
                next;
            }
            my $size = (stat($safe))[7] || 0;
            if (unlink $safe) {
                push @results, { path => $safe, success => JSON::XS::true(), message => 'Deleted (' . format_bytes($size) . ' freed)', freed => $size };
            } else {
                push @results, { path => $safe, success => JSON::XS::false(), message => "Could not delete: $!" };
            }
            select(undef, undef, undef, 0.01);
        }
        print JSON::XS->new->encode({ results => \@results });
        exit;
    }

    print JSON::XS->new->encode({ error => 'Unknown action' });
    exit;
}

# ── HELPERS ───────────────────────────────────────────────────────────────────

sub trim { my $s = shift; $s =~ s/^\s+|\s+$//g; return $s; }

sub format_bytes {
    my $b = int(shift || 0);
    return sprintf('%.2f GB', $b / 1073741824) if $b >= 1073741824;
    return sprintf('%.2f MB', $b / 1048576)    if $b >= 1048576;
    return sprintf('%.2f KB', $b / 1024)       if $b >= 1024;
    return "$b B";
}

sub format_date {
    my $t  = shift || 0;
    my @tm = localtime($t);
    return sprintf('%04d-%02d-%02d %02d:%02d', $tm[5]+1900, $tm[4]+1, $tm[3], $tm[2], $tm[1]);
}

sub match_domain {
    my ($filename, $domain_map) = @_;
    my $base = $filename;
    $base =~ s/\.php\.error\.log$//;
    $base = lc($base);
    return $domain_map->{$base} if exists $domain_map->{$base};
    my $norm = $base;
    $norm =~ s/[\.\-]/_/g;
    return $domain_map->{$norm} if exists $domain_map->{$norm};
    $base =~ s/_/./g;
    return $base;
}

sub find_error_logs {
    my ($dir) = @_;
    my @found;
    return @found unless -d $dir;
    opendir(my $dh, $dir) or return @found;
    my @entries = readdir($dh);
    closedir($dh);
    for my $entry (@entries) {
        next if $entry eq '.' || $entry eq '..';
        my $path = "$dir/$entry";
        if    (-d $path && !-l $path)                              { push @found, find_error_logs($path); }
        elsif ($entry eq 'error_log' && -f $path && !-l $path)    { push @found, $path; }
    }
    return @found;
}

sub build_summary {
    my ($files) = @_;
    my (%users, %domains);
    my ($total, $reclaimable, $candidates) = (0, 0, 0);
    for my $f (@$files) {
        $users{$f->{user}}     = 1;
        $domains{$f->{domain}} = 1;
        $total += $f->{size};
        if ($f->{candidate}) {
            $candidates++;
            $reclaimable += $f->{size};
        }
    }
    return {
        users             => scalar keys %users,
        domains           => scalar keys %domains,
        files             => scalar @$files,
        candidates        => $candidates,
        total_size_human  => format_bytes($total),
        reclaimable_human => format_bytes($reclaimable),
    };
}

sub sanitise_path {
    my ($path, $mode) = @_;
    my $real = eval { abs_path($path) };
    return undef unless $real && -f $real && !-l $real;
    if ($mode eq 'fpm') {
        return undef unless $real =~ m{^/home/[^/]+/logs/[^/]+\.php\.error\.log$};
    } else {
        return undef unless $real =~ m{^/home/[^/]+/public_html/};
        return undef unless (split '/', $real)[-1] eq 'error_log';
    }
    return $real;
}

# ── HTML ──────────────────────────────────────────────────────────────────────

print "Content-Type: text/html\r\n\r\n";

Whostmgr::HTMLInterface::defheader(
    'Error Log Manager',
    '',
    '/cgi/errorlogmanager/errorlogmanager.cgi',
    undef, undef, undef, undef, 'yui',
    'errorlogmanager'
);

print <<'HTML';
<style>
#elm-wrap { font-family:"Open Sans",Arial,sans-serif; font-size:13px; color:#333; max-width:1200px; padding:10px 0 40px; }

/* MODE BAR */
#elm-modebar { display:flex; align-items:center; gap:16px; background:#fff; border:1px solid #ddd; border-radius:4px; padding:12px 16px; margin-bottom:15px; flex-wrap:wrap; }
#elm-modebar label { font-weight:600; color:#555; font-size:12px; text-transform:uppercase; letter-spacing:0.04em; }
.elm-mode-btn { padding:6px 18px; border:1px solid #ccc; border-radius:3px; background:#f7f7f7; font-size:13px; cursor:pointer; color:#333; transition:all 0.15s; }
.elm-mode-btn.active { background:#5b9bd5; border-color:#4a8bc4; color:#fff; font-weight:600; }
.elm-mode-btn:hover:not(.active) { background:#eee; }
#elm-autodetect { font-size:12px; color:#888; margin-left:auto; font-style:italic; }

/* CONTROLS */
#elm-controls { display:flex; align-items:flex-end; gap:20px; background:#fff; border:1px solid #ddd; border-radius:4px; padding:12px 16px; margin-bottom:15px; flex-wrap:wrap; }
.elm-ctrl-group { display:flex; flex-direction:column; gap:5px; }
.elm-ctrl-group label { font-size:12px; font-weight:600; color:#555; }
.elm-input-unit { display:flex; align-items:center; gap:6px; }
.elm-input-unit input[type=number] { width:80px; padding:5px 8px; border:1px solid #ccc; border-radius:3px; font-size:13px; }
.elm-input-unit input:focus { outline:none; border-color:#5b9bd5; }
.elm-unit { font-size:12px; color:#888; }
.elm-ctrl-action { margin-left:auto; }

/* BUTTONS */
.elm-btn { display:inline-block; padding:6px 16px; font-size:13px; font-weight:600; border-radius:3px; border:1px solid transparent; cursor:pointer; transition:all 0.15s; white-space:nowrap; }
.elm-btn-primary { background:#5b9bd5; border-color:#4a8bc4; color:#fff; }
.elm-btn-primary:hover:not(:disabled) { background:#4a8bc4; }
.elm-btn-primary:disabled { opacity:0.6; cursor:not-allowed; }
.elm-btn-default { background:#fff; border-color:#ccc; color:#333; }
.elm-btn-default:hover:not(:disabled) { background:#f5f5f5; }
.elm-btn-default:disabled { opacity:0.5; cursor:not-allowed; }
.elm-btn-danger { background:#d9534f; border-color:#c9302c; color:#fff; }
.elm-btn-danger:hover:not(:disabled) { background:#c9302c; }
.elm-btn-danger:disabled { opacity:0.5; cursor:not-allowed; }
.elm-btn-warn { background:#e67e22; border-color:#d35400; color:#fff; }
.elm-btn-warn:hover:not(:disabled) { background:#d35400; }
.elm-btn-sm { padding:3px 10px; font-size:12px; }

/* ALERTS */
.elm-alert { padding:10px 15px; border-radius:4px; border:1px solid transparent; margin-bottom:15px; font-size:13px; }
.elm-alert-warning { background:#fcf8e3; border-color:#faebcc; color:#8a6d3b; }

/* PANEL */
.elm-panel { background:#fff; border:1px solid #ddd; border-radius:4px; margin-bottom:15px; }
.elm-panel-header { padding:10px 15px; border-bottom:1px solid #ddd; background:#f7f7f7; border-radius:4px 4px 0 0; display:flex; align-items:center; justify-content:space-between; }
.elm-panel-header h3 { margin:0; font-size:14px; font-weight:600; color:#333; }
.elm-panel-body { padding:15px; }
.elm-text-center { text-align:center; }
.elm-text-success { color:#3c763d; }

/* SUMMARY */
#elm-summary { display:flex; border:1px solid #ddd; border-radius:4px; background:#fff; margin-bottom:15px; overflow:hidden; }
.elm-sum-item { flex:1; padding:12px 15px; text-align:center; border-right:1px solid #eee; }
.elm-sum-item:last-child { border-right:none; }
.elm-sum-val { font-size:20px; font-weight:700; color:#2c3e50; }
.elm-sum-key { font-size:11px; color:#888; text-transform:uppercase; letter-spacing:0.04em; margin-top:2px; }
.elm-sum-item--warn .elm-sum-val { color:#e67e22; }
.elm-sum-item--ok .elm-sum-val { color:#27ae60; }

/* GROUP BULK BARS */
.elm-group-actions { display:flex; align-items:center; justify-content:space-between; padding:6px 12px; background:#f0f4f8; border-bottom:1px solid #ddd; }
.elm-group-actions-left { display:flex; align-items:center; gap:10px; }
.elm-chk-label { display:flex; align-items:center; gap:6px; cursor:pointer; user-select:none; font-size:12px; }
.elm-text-muted { color:#888; font-size:12px; }

/* GLOBAL BULK BAR */
#elm-bulkbar { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; padding:10px 15px; background:#fff; border:1px solid #ddd; border-radius:4px; margin-bottom:15px; }
.elm-bulk-left { display:flex; align-items:center; gap:12px; }
.elm-bulk-actions { display:flex; gap:8px; flex-wrap:wrap; }

/* TABLE */
.elm-table-wrap { overflow-x:auto; }
.elm-table { width:100%; border-collapse:collapse; font-size:13px; }
.elm-table thead { background:#f7f7f7; border-bottom:2px solid #ddd; }
.elm-table th { padding:8px 12px; text-align:left; font-weight:600; color:#555; font-size:12px; white-space:nowrap; }
.elm-table th.sortable { cursor:pointer; }
.elm-table th.sortable:hover { color:#2c3e50; }
.elm-table td { padding:8px 12px; border-bottom:1px solid #f0f0f0; vertical-align:middle; }
.elm-table tbody tr:hover td { background:#f9f9f9; }
.elm-table tbody tr:last-child td { border-bottom:none; }

/* GROUP ROWS */
tr.elm-group-user td { background:#2c3e50; color:#fff; padding:8px 12px; font-weight:700; font-size:12px; text-transform:uppercase; letter-spacing:0.06em; }
tr.elm-group-domain td { background:#ecf0f1; color:#555; padding:5px 12px 5px 24px; font-weight:600; font-size:12px; border-bottom:1px solid #ddd; }

/* BADGES */
.elm-badge { display:inline-block; padding:2px 7px; border-radius:10px; font-size:11px; font-weight:600; }
.elm-badge-warn { background:#fcf8e3; color:#8a6d3b; border:1px solid #faebcc; }
.elm-badge-ok { background:#dff0d8; color:#3c763d; border:1px solid #d6e9c6; }

/* ACTION BUTTONS */
.elm-act-btn { display:inline-block; padding:2px 8px; font-size:12px; border:1px solid #ccc; border-radius:3px; background:#fff; cursor:pointer; color:#555; margin-right:3px; transition:all 0.15s; text-decoration:none; }
.elm-act-btn:hover { background:#f5f5f5; color:#333; }
.elm-act-btn-delete { color:#d9534f; border-color:#d9534f; }
.elm-act-btn-delete:hover { background:#fdf2f2; }
.elm-act-btn-cse { color:#5b9bd5; border-color:#5b9bd5; }
.elm-act-btn-cse:hover { background:#eaf3fb; }

/* COLUMNS */
td.col-path { font-family:monospace; font-size:12px; max-width:320px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
td.col-size, td.col-age { text-align:right; font-family:monospace; font-size:12px; white-space:nowrap; }
td.col-modified { font-size:12px; color:#777; white-space:nowrap; }

/* SPINNER */
.elm-spinner { width:32px; height:32px; border:3px solid #ddd; border-top-color:#5b9bd5; border-radius:50%; animation:elm-spin 0.8s linear infinite; margin:15px auto 10px; }
@keyframes elm-spin { to { transform:rotate(360deg); } }

/* ACTIVITY LOG */
.elm-activity-log { max-height:200px; overflow-y:auto; }
.elm-activity-line { display:flex; gap:12px; padding:6px 15px; border-bottom:1px solid #f5f5f5; font-size:12px; font-family:monospace; }
.elm-activity-time { color:#aaa; flex-shrink:0; }
.elm-activity-success .elm-activity-msg { color:#3c763d; }
.elm-activity-error .elm-activity-msg { color:#d9534f; }
.elm-activity-info .elm-activity-msg { color:#31708f; }
.elm-activity-warn .elm-activity-msg { color:#8a6d3b; }

/* MODAL */
#elm-modal-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.5); display:flex; align-items:center; justify-content:center; z-index:9999; }
.elm-modal-box { background:#fff; border:1px solid #ddd; border-radius:4px; padding:24px; max-width:440px; width:90%; box-shadow:0 4px 20px rgba(0,0,0,0.2); }
.elm-modal-box h3 { margin:0 0 12px; font-size:16px; color:#2c3e50; }
.elm-modal-box p { color:#555; margin-bottom:20px; line-height:1.5; }
.elm-modal-actions { display:flex; gap:8px; justify-content:flex-end; }
</style>

<div id="elm-wrap">

    <!-- MODE SELECTOR -->
    <div id="elm-modebar">
        <label>Scan Mode:</label>
        <button class="elm-mode-btn active" id="btn-mode-fpm"    onclick="setMode('fpm')">FPM Mode</button>
        <button class="elm-mode-btn"        id="btn-mode-legacy" onclick="setMode('legacy')">Legacy Mode</button>
        <span id="elm-autodetect"></span>
    </div>

    <!-- CONTROLS -->
    <div id="elm-controls">
        <div class="elm-ctrl-group" id="ctrl-age-wrap">
            <label for="age-threshold">Flag logs older than</label>
            <div class="elm-input-unit">
                <input type="number" id="age-threshold" value="5" min="1" max="365">
                <span class="elm-unit">days</span>
            </div>
        </div>
        <div class="elm-ctrl-group">
            <label for="load-threshold">Pause if load exceeds</label>
            <div class="elm-input-unit">
                <input type="number" id="load-threshold" value="4.0" min="0.5" max="64" step="0.1">
                <span class="elm-unit">avg</span>
            </div>
        </div>
        <div class="elm-ctrl-group elm-ctrl-action">
            <label>&nbsp;</label>
            <button id="btn-scan" class="elm-btn elm-btn-primary" onclick="initiateScan()">Scan Logs</button>
        </div>
    </div>

    <!-- LOAD WARNING -->
    <div id="elm-load-warning" class="elm-alert elm-alert-warning" style="display:none;">
        <strong>Warning:</strong> <span id="elm-load-text"></span>
        <button class="elm-btn elm-btn-sm elm-btn-default" onclick="dismissLoadWarning()" style="margin-left:10px;">Proceed Anyway</button>
    </div>

    <!-- SCANNING -->
    <div id="elm-scanning" class="elm-panel" style="display:none;">
        <div class="elm-panel-body elm-text-center">
            <div class="elm-spinner"></div>
            <p>Scanning&hellip;</p>
        </div>
    </div>

    <!-- EMPTY STATE -->
    <div id="elm-empty" class="elm-panel" style="display:none;">
        <div class="elm-panel-body elm-text-center">
            <p class="elm-text-success"><strong>No log files found matching your criteria.</strong></p>
        </div>
    </div>

    <!-- RESULTS -->
    <div id="elm-results" style="display:none;">

        <!-- SUMMARY -->
        <div id="elm-summary">
            <div class="elm-sum-item">
                <div class="elm-sum-val" id="sum-users">0</div>
                <div class="elm-sum-key">Users</div>
            </div>
            <div class="elm-sum-item">
                <div class="elm-sum-val" id="sum-domains">0</div>
                <div class="elm-sum-key">Domains</div>
            </div>
            <div class="elm-sum-item">
                <div class="elm-sum-val" id="sum-files">0</div>
                <div class="elm-sum-key">Log Files</div>
            </div>
            <div class="elm-sum-item elm-sum-item--warn">
                <div class="elm-sum-val" id="sum-candidates">0</div>
                <div class="elm-sum-key">Candidates</div>
            </div>
            <div class="elm-sum-item">
                <div class="elm-sum-val" id="sum-size">0 B</div>
                <div class="elm-sum-key">Total Size</div>
            </div>
            <div class="elm-sum-item elm-sum-item--ok">
                <div class="elm-sum-val" id="sum-reclaimable">0 B</div>
                <div class="elm-sum-key">Reclaimable</div>
            </div>
        </div>

        <!-- GLOBAL BULK BAR -->
        <div id="elm-bulkbar">
            <div class="elm-bulk-left">
                <label class="elm-chk-label">
                    <input type="checkbox" id="chk-all-global" onchange="toggleAllGlobal(this.checked)">
                    Select all candidates
                </label>
                <span class="elm-text-muted"><span id="selected-count">0</span> selected</span>
            </div>
            <div class="elm-bulk-actions">
                <button id="btn-delete-all-legacy" class="elm-btn elm-btn-warn" onclick="deleteAllLegacy()" style="display:none;">Delete ALL error_log Files</button>
                <button id="btn-delete-selected"   class="elm-btn elm-btn-danger" onclick="bulkDelete()" disabled>Delete Selected</button>
            </div>
        </div>

        <!-- TABLE -->
        <div class="elm-panel">
            <div class="elm-table-wrap">
                <table class="elm-table">
                    <thead>
                        <tr>
                            <th style="width:36px;"></th>
                            <th onclick="sortTable('domain')" class="sortable">Domain</th>
                            <th onclick="sortTable('path')"   class="sortable">Path / File</th>
                            <th onclick="sortTable('size')"   class="sortable" style="text-align:right;">Size</th>
                            <th onclick="sortTable('age')"    class="sortable" style="text-align:right;">Age</th>
                            <th>Last Modified</th>
                            <th>Status</th>
                            <th style="width:120px;">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="log-tbody"></tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- ACTIVITY LOG -->
    <div id="elm-activity-section" class="elm-panel" style="display:none;">
        <div class="elm-panel-header">
            <h3>Activity Log</h3>
            <button class="elm-btn elm-btn-sm elm-btn-default" onclick="clearActivity()">Clear</button>
        </div>
        <div class="elm-panel-body" style="padding:0;">
            <div id="elm-activity-log" class="elm-activity-log"></div>
        </div>
    </div>

</div>

<!-- CONFIRM MODAL -->
<div id="elm-modal-overlay" style="display:none;">
    <div class="elm-modal-box">
        <h3 id="modal-title">Confirm</h3>
        <p id="modal-body"></p>
        <div class="elm-modal-actions">
            <button class="elm-btn elm-btn-default" onclick="closeModal()">Cancel</button>
            <button class="elm-btn elm-btn-danger"  id="modal-confirm">Confirm</button>
        </div>
    </div>
</div>

<script>
var _base = window.location.pathname.replace(/errorlogmanager\.cgi(\?.*)?$/, '');
document.write('<scr'+'ipt src="' + _base + 'assets/app.js?v=3"><\/scr'+'ipt>');
</script>
HTML

Whostmgr::HTMLInterface::deffooter();
