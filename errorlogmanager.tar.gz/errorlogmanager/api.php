<?php
/*
 * WHM Error Log Manager - API
 * Handles: scan, delete, rotate, load, autodetect
 */

// REMOTE_USER is set by WHM for all authenticated CGI requests
// Confirmed from Whostmgr::ACLS source
if (empty($_SERVER['REMOTE_USER'])) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(array('error' => 'Access denied - no WHM session'));
    exit;
}

header('Content-Type: application/json');

$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');

switch ($action) {
    case 'autodetect': handleAutodetect(); break;
    case 'scan':       handleScan();       break;
    case 'delete':     handleDelete();     break;
    case 'rotate':     handleRotate();     break;
    case 'load':       handleLoad();       break;
    default:           respond(array('error' => 'Unknown action'));
}

// ─────────────────────────────────────────────
// AUTODETECT
// ─────────────────────────────────────────────
function handleAutodetect() {
    $mode   = 'legacy';
    $reason = 'No FPM logs found in /home/*/logs/';

    // Check for FPM pool configs
    $fpmPools = glob('/opt/cpanel/ea-php*/root/etc/php-fpm.d/*.conf');
    if (!empty($fpmPools)) {
        $mode   = 'fpm';
        $reason = 'EA-PHP FPM pool configs detected';
        respond(array('mode' => $mode, 'reason' => $reason));
        return;
    }

    // Check for actual .php.error.log files
    $logDirs = glob('/home/*/logs', GLOB_ONLYDIR);
    if ($logDirs) {
        foreach ($logDirs as $dir) {
            $logs = glob($dir . '/*.php.error.log');
            if (!empty($logs)) {
                $mode   = 'fpm';
                $reason = 'PHP FPM error logs found in /home/*/logs/';
                break;
            }
        }
    }

    respond(array('mode' => $mode, 'reason' => $reason));
}

// ─────────────────────────────────────────────
// BUILD DOMAIN MAP from /etc/userdatadomains
// ─────────────────────────────────────────────
function buildDomainMap() {
    $map  = array(); // sanitised_key => domain
    $file = '/etc/userdatadomains';
    if (!file_exists($file)) return $map;

    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        $pos = strpos($line, ':');
        if ($pos === false) continue;
        $domain = trim(substr($line, 0, $pos));
        // Build sanitised key: lowercase, replace dots and hyphens with underscore
        $key = strtolower(preg_replace('/[\.\-]/', '_', $domain));
        $map[$key] = $domain;
    }
    return $map;
}

function matchDomain($filename, $domainMap) {
    // Strip .php.error.log suffix
    $base = preg_replace('/\.php\.error\.log$/', '', $filename);
    $base = strtolower($base);

    // Direct match
    if (isset($domainMap[$base])) return $domainMap[$base];

    // Normalise and try again — replace any mix of dots/hyphens with underscore
    $normalised = preg_replace('/[\.\-]/', '_', $base);
    if (isset($domainMap[$normalised])) return $domainMap[$normalised];

    // Try partial matches — find closest key
    foreach ($domainMap as $key => $domain) {
        if ($key === $normalised) return $domain;
    }

    // Fall back to filename base as display name
    return str_replace('_', '.', $base);
}

// ─────────────────────────────────────────────
// SCAN
// ─────────────────────────────────────────────
function handleScan() {
    $mode    = isset($_POST['mode']) ? $_POST['mode'] : 'fpm';
    $ageDays = isset($_POST['age_days']) ? (int) $_POST['age_days'] : 5;
    if ($ageDays < 1) $ageDays = 1;
    $cutoff = time() - ($ageDays * 86400);

    if ($mode === 'fpm') {
        scanFpm($cutoff);
    } else {
        scanLegacy($cutoff);
    }
}

function scanFpm($cutoff) {
    $domainMap = buildDomainMap();
    $results   = array();
    $skip      = array('nobody', 'mail', 'ftp', 'cpanel', 'root', 'virtfs');

    $logDirs = glob('/home/*/logs', GLOB_ONLYDIR);
    if (!$logDirs) {
        respond(array('files' => array(), 'summary' => emptySummary()));
        return;
    }

    foreach ($logDirs as $logsDir) {
        if (!preg_match('#^/home/([^/]+)/logs$#', $logsDir, $m)) continue;
        $username = $m[1];
        if (in_array($username, $skip)) continue;

        $logs = glob($logsDir . '/*.php.error.log');
        if (!$logs) continue;

        foreach ($logs as $filepath) {
            if (!is_file($filepath) || is_link($filepath)) continue;
            $filename    = basename($filepath);
            $domain      = matchDomain($filename, $domainMap);
            $mtime       = (int) @filemtime($filepath);
            $size        = (int) @filesize($filepath);
            $ageDays     = (int) floor((time() - $mtime) / 86400);
            $isCandidate = ($mtime < $cutoff);

            $results[] = array(
                'user'        => $username,
                'domain'      => $domain,
                'file'        => $filename,
                'path'        => $filepath,
                'size'        => $size,
                'size_human'  => formatBytes($size),
                'mtime'       => $mtime,
                'mtime_human' => date('Y-m-d H:i', $mtime),
                'age_days'    => $ageDays,
                'candidate'   => $isCandidate,
                'mode'        => 'fpm',
            );
        }
    }

    usort($results, function($a, $b) {
        $u = strcmp($a['user'], $b['user']);
        if ($u !== 0) return $u;
        return strcmp($a['domain'], $b['domain']);
    });

    respond(array('files' => $results, 'summary' => buildSummary($results)));
}

function scanLegacy($cutoff) {
    $results = array();
    $skip    = array('nobody', 'mail', 'ftp', 'cpanel', 'root', 'virtfs');

    $homeDirs = glob('/home/*', GLOB_ONLYDIR);
    if (!$homeDirs) {
        respond(array('files' => array(), 'summary' => emptySummary()));
        return;
    }

    foreach ($homeDirs as $homeDir) {
        if (!preg_match('#^/home/([^/]+)$#', $homeDir, $m)) continue;
        $username = $m[1];
        if (in_array($username, $skip)) continue;

        $publicHtml = $homeDir . '/public_html';
        if (!is_dir($publicHtml)) continue;

        // Recursive scan for error_log files
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($publicHtml, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $file) {
            if (!$file->isFile()) continue;
            if ($file->getFilename() !== 'error_log') continue;
            if (is_link($file->getPathname())) continue;

            $filepath = $file->getPathname();
            $mtime    = (int) @filemtime($filepath);
            $size     = (int) @filesize($filepath);
            $ageDays  = (int) floor((time() - $mtime) / 86400);

            // Extract domain from path for display
            $relPath = str_replace($publicHtml . '/', '', $filepath);
            $parts   = explode('/', $relPath);
            $domain  = count($parts) > 1 ? $parts[0] : $username;

            $results[] = array(
                'user'        => $username,
                'domain'      => $domain,
                'file'        => 'error_log',
                'path'        => $filepath,
                'size'        => $size,
                'size_human'  => formatBytes($size),
                'mtime'       => $mtime,
                'mtime_human' => date('Y-m-d H:i', $mtime),
                'age_days'    => $ageDays,
                'candidate'   => true, // all legacy logs are candidates
                'mode'        => 'legacy',
            );
        }
    }

    usort($results, function($a, $b) {
        $u = strcmp($a['user'], $b['user']);
        if ($u !== 0) return $u;
        return strcmp($a['domain'], $b['domain']);
    });

    respond(array('files' => $results, 'summary' => buildSummary($results)));
}

// ─────────────────────────────────────────────
// DELETE
// ─────────────────────────────────────────────
function handleDelete() {
    $paths   = isset($_POST['paths']) ? $_POST['paths'] : array();
    $mode    = isset($_POST['mode']) ? $_POST['mode'] : 'fpm';
    $results = array();

    foreach ($paths as $path) {
        $safe = sanitisePath($path, $mode);
        if ($safe === false) {
            $results[] = array('path' => $path, 'success' => false, 'message' => 'Invalid or unsafe path');
            continue;
        }
        if (!file_exists($safe)) {
            $results[] = array('path' => $safe, 'success' => false, 'message' => 'File not found');
            continue;
        }
        $size = (int) @filesize($safe);
        if (@unlink($safe)) {
            $results[] = array('path' => $safe, 'success' => true, 'message' => 'Deleted (' . formatBytes($size) . ' freed)', 'freed' => $size);
        } else {
            $results[] = array('path' => $safe, 'success' => false, 'message' => 'Could not delete — check permissions');
        }
        usleep(10000);
    }

    respond(array('results' => $results));
}

// ─────────────────────────────────────────────
// ROTATE (truncate in place) — FPM only
// ─────────────────────────────────────────────
function handleRotate() {
    $paths   = isset($_POST['paths']) ? $_POST['paths'] : array();
    $results = array();

    foreach ($paths as $path) {
        $safe = sanitisePath($path, 'fpm');
        if ($safe === false) {
            $results[] = array('path' => $path, 'success' => false, 'message' => 'Invalid or unsafe path');
            continue;
        }
        if (!file_exists($safe)) {
            $results[] = array('path' => $safe, 'success' => false, 'message' => 'File not found');
            continue;
        }
        $sizeBefore = (int) @filesize($safe);
        $fh = @fopen($safe, 'w');
        if ($fh !== false) {
            fclose($fh);
            $results[] = array('path' => $safe, 'success' => true, 'message' => 'Truncated — ' . formatBytes($sizeBefore) . ' cleared', 'freed' => $sizeBefore);
        } else {
            $results[] = array('path' => $safe, 'success' => false, 'message' => 'Could not truncate — check permissions');
        }
        usleep(10000);
    }

    respond(array('results' => $results));
}

// ─────────────────────────────────────────────
// LOAD CHECK
// ─────────────────────────────────────────────
function handleLoad() {
    $load = sys_getloadavg();
    respond(array(
        'load_1'  => round($load[0], 2),
        'load_5'  => round($load[1], 2),
        'load_15' => round($load[2], 2),
    ));
}

// ─────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────

function sanitisePath($path, $mode) {
    $real = realpath($path);
    if ($real === false) return false;
    if (is_link($real)) return false;
    if (!is_file($real)) return false;

    if ($mode === 'fpm') {
        // Must be /home/[user]/logs/[file].php.error.log
        if (!preg_match('#^/home/[^/]+/logs/[^/]+\.php\.error\.log$#', $real)) return false;
    } else {
        // Must be /home/[user]/public_html/[...]/error_log
        if (!preg_match('#^/home/[^/]+/public_html/.+/error_log$#', $real) &&
            !preg_match('#^/home/[^/]+/public_html/error_log$#', $real)) return false;
        if (basename($real) !== 'error_log') return false;
    }

    return $real;
}

function formatBytes($bytes) {
    $bytes = (int) $bytes;
    if ($bytes >= 1073741824) return round($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576)    return round($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024)       return round($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

function buildSummary($files) {
    $users       = array();
    $domains     = array();
    $totalSize   = 0;
    $reclaimable = 0;
    $candidates  = 0;

    foreach ($files as $f) {
        $users[$f['user']]     = true;
        $domains[$f['domain']] = true;
        $totalSize += $f['size'];
        if ($f['candidate']) {
            $candidates++;
            $reclaimable += $f['size'];
        }
    }

    return array(
        'users'             => count($users),
        'domains'           => count($domains),
        'files'             => count($files),
        'candidates'        => $candidates,
        'total_size_human'  => formatBytes($totalSize),
        'reclaimable_human' => formatBytes($reclaimable),
    );
}

function emptySummary() {
    return array(
        'users' => 0, 'domains' => 0, 'files' => 0, 'candidates' => 0,
        'total_size_human' => '0 B', 'reclaimable_human' => '0 B',
    );
}

function respond($data) {
    echo json_encode($data);
    exit;
}
