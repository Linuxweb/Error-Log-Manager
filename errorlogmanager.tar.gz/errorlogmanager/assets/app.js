'use strict';

// ── STATE ─────────────────────────────────────────────────────────────────────
var State = {
    files:        [],
    selected:     {},
    mode:         'fpm',
    cseInstalled: false,
    sortCol:      'user',
    sortDir:      'asc',
    loadOverride: false
};

var API_URL = window.location.pathname.split('?')[0];

// ── INIT ──────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
    autodetectMode();
    startLoadPolling();
});

// ── MODE ──────────────────────────────────────────────────────────────────────
function autodetectMode() {
    apiCall('autodetect', {}).then(function(data) {
        State.mode         = data.mode;
        State.cseInstalled = data.cse ? true : false;
        updateModeUI();
        hideResults();
        document.getElementById('elm-autodetect').textContent = 'Auto-detected: ' + data.reason;
    }).catch(function() {
        State.mode = 'fpm';
        updateModeUI();
        document.getElementById('elm-autodetect').textContent = 'Auto-detect failed — defaulting to FPM';
    });
}

window.setMode = function(mode) {
    State.mode = mode;
    document.getElementById('elm-autodetect').textContent = 'Manually selected';
    updateModeUI();
    hideResults();
};

function updateModeUI() {
    document.getElementById('btn-mode-fpm').className    = 'elm-mode-btn' + (State.mode === 'fpm'    ? ' active' : '');
    document.getElementById('btn-mode-legacy').className = 'elm-mode-btn' + (State.mode === 'legacy' ? ' active' : '');
    document.getElementById('ctrl-age-wrap').style.display    = State.mode === 'fpm' ? 'flex' : 'none';
    document.getElementById('btn-delete-all-legacy').style.display = State.mode === 'legacy' ? 'inline-block' : 'none';
}

// ── LOAD POLLING ──────────────────────────────────────────────────────────────
function startLoadPolling() {
    pollLoad();
    setInterval(pollLoad, 15000);
}

function pollLoad() {
    apiCall('load', {}).then(function(data) {
        var threshold = parseFloat(document.getElementById('load-threshold').value);
        if (!State.loadOverride && data.load_1 > threshold) {
            showLoadWarning(data.load_1, threshold);
        } else {
            document.getElementById('elm-load-warning').style.display = 'none';
        }
    }).catch(function() {});
}

function showLoadWarning(load, threshold) {
    document.getElementById('elm-load-text').textContent =
        'Server load (' + load.toFixed(2) + ') exceeds threshold (' + threshold + '). Operations are paused.';
    document.getElementById('elm-load-warning').style.display = 'block';
}

window.dismissLoadWarning = function() {
    State.loadOverride = true;
    document.getElementById('elm-load-warning').style.display = 'none';
};

// ── SCAN ──────────────────────────────────────────────────────────────────────
window.initiateScan = function() {
    var threshold = parseFloat(document.getElementById('load-threshold').value);
    apiCall('load', {}).then(function(loadData) {
        if (!State.loadOverride && loadData.load_1 > threshold) {
            showLoadWarning(loadData.load_1, threshold);
            return;
        }
        doScan();
    }).catch(function() { doScan(); });
};

function doScan() {
    State.selected     = {};
    State.loadOverride = false;
    showScanning();

    var params = {
        mode:     State.mode,
        age_days: parseInt(document.getElementById('age-threshold').value) || 5
    };

    apiCall('scan', params).then(function(data) {
        State.files = data.files || [];
        renderResults(data.summary || {});
        logActivity('info', 'Scan complete — ' + State.files.length + ' files found.');
    }).catch(function(e) {
        hideScanning();
        logActivity('error', 'Scan failed: ' + e.message);
    });
}

// ── RENDER ────────────────────────────────────────────────────────────────────
function renderResults(summary) {
    hideScanning();

    if (State.files.length === 0) {
        document.getElementById('elm-empty').style.display   = 'block';
        document.getElementById('elm-results').style.display = 'none';
        return;
    }

    document.getElementById('elm-empty').style.display   = 'none';
    document.getElementById('elm-results').style.display = 'block';

    document.getElementById('sum-users').textContent       = summary.users       || 0;
    document.getElementById('sum-domains').textContent     = summary.domains     || 0;
    document.getElementById('sum-files').textContent       = summary.files       || 0;
    document.getElementById('sum-candidates').textContent  = summary.candidates  || 0;
    document.getElementById('sum-size').textContent        = summary.total_size_human    || '0 B';
    document.getElementById('sum-reclaimable').textContent = summary.reclaimable_human   || '0 B';

    renderTable();
    updateBulkButtons();
}

function renderTable() {
    var sorted = sortFiles(State.files);
    var tbody  = document.getElementById('log-tbody');
    tbody.innerHTML = '';

    // Group files by user then domain
    var groups = {};
    var userOrder = [];
    sorted.forEach(function(file) {
        if (!groups[file.user]) {
            groups[file.user] = {};
            userOrder.push(file.user);
        }
        if (!groups[file.user][file.domain]) {
            groups[file.user][file.domain] = [];
        }
        groups[file.user][file.domain].push(file);
    });

    userOrder.forEach(function(user) {
        var domainOrder = Object.keys(groups[user]).sort();

        // Collect all files for this user for "select all in user" checkbox
        var userFiles = [];
        domainOrder.forEach(function(domain) {
            groups[user][domain].forEach(function(f) { userFiles.push(f); });
        });
        var userCandidates = userFiles.filter(function(f) { return f.candidate; });
        var userSelectedCount = userFiles.filter(function(f) { return State.selected[f.path]; }).length;

        // User group header row with its own select-all
        var userRow = document.createElement('tr');
        userRow.className = 'elm-group-user';
        userRow.innerHTML =
            '<td colspan="8">' +
            '<div style="display:flex;align-items:center;justify-content:space-between;">' +
            '<span>' + esc(user) + '</span>' +
            '<div style="display:flex;align-items:center;gap:12px;">' +
            (userCandidates.length > 0 ?
                '<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:normal;font-size:12px;color:#ccc;">' +
                '<input type="checkbox" class="chk-user" data-user="' + esc(user) + '" ' +
                (userSelectedCount === userCandidates.length && userCandidates.length > 0 ? 'checked' : '') +
                ' onchange="toggleUserCandidates(\'' + esc(user) + '\',this.checked)"> Select all candidates</label>' : '') +
            '<span style="font-size:12px;color:#aaa;">' + userFiles.length + ' file(s)</span>' +
            '</div></div>' +
            '</td>';
        tbody.appendChild(userRow);

        domainOrder.forEach(function(domain) {
            var domainFiles      = groups[user][domain];
            var domainCandidates = domainFiles.filter(function(f) { return f.candidate; });
            var domainSelected   = domainFiles.filter(function(f) { return State.selected[f.path]; }).length;

            // Domain group header with its own select-all
            var domRow = document.createElement('tr');
            domRow.className = 'elm-group-domain';
            domRow.innerHTML =
                '<td colspan="8">' +
                '<div style="display:flex;align-items:center;justify-content:space-between;">' +
                '<span>' + esc(domain) + '</span>' +
                '<div style="display:flex;align-items:center;gap:12px;">' +
                (domainCandidates.length > 0 ?
                    '<label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-weight:normal;font-size:11px;">' +
                    '<input type="checkbox" class="chk-domain" data-user="' + esc(user) + '" data-domain="' + esc(domain) + '" ' +
                    (domainSelected === domainCandidates.length && domainCandidates.length > 0 ? 'checked' : '') +
                    ' onchange="toggleDomainCandidates(\'' + esc(user) + '\',\'' + esc(domain) + '\',this.checked)"> Select all</label>' : '') +
                '<span style="font-size:11px;color:#888;">' + domainFiles.length + ' file(s)</span>' +
                '</div></div>' +
                '</td>';
            tbody.appendChild(domRow);

            // File rows
            domainFiles.forEach(function(file) {
                var tr = document.createElement('tr');

                var checked = State.selected[file.path] ? 'checked' : '';
                var badge   = file.candidate
                    ? '<span class="elm-badge elm-badge-warn">Candidate</span>'
                    : '<span class="elm-badge elm-badge-ok">Recent</span>';

                // Path display — full relative path for legacy, filename for FPM
                var pathDisplay = State.mode === 'legacy' && file.rel_path
                    ? file.rel_path
                    : file.file;

                // Actions
                var actions = '';
                if (State.cseInstalled && file.parent_dir) {
                    var cseUrl = buildCseUrl(file.parent_dir);
                    actions += '<a class="elm-act-btn elm-act-btn-cse" href="' + esc(cseUrl) + '" target="_blank" title="Open in ConfigServer Explorer">CSE</a>';
                }
                actions += '<button class="elm-act-btn elm-act-btn-delete" onclick="singleDelete(\'' + esc(file.path) + '\')">Delete</button>';

                tr.innerHTML =
                    '<td><input type="checkbox" class="row-check" data-path="' + esc(file.path) + '" ' + checked +
                    ' onchange="toggleFile(\'' + esc(file.path) + '\',\'' + esc(user) + '\',\'' + esc(domain) + '\',this.checked)"></td>' +
                    '<td>' + esc(file.domain) + '</td>' +
                    '<td class="col-path" title="' + esc(file.path) + '">' + esc(pathDisplay) + '</td>' +
                    '<td class="col-size">' + esc(file.size_human) + '</td>' +
                    '<td class="col-age">'  + file.age_days + 'd</td>' +
                    '<td class="col-modified">' + esc(file.mtime_human) + '</td>' +
                    '<td>' + badge + '</td>' +
                    '<td>' + actions + '</td>';

                tbody.appendChild(tr);
            });
        });
    });

    updateSelectedCount();
}

function buildCseUrl(dir) {
    var base = window.location.pathname.replace(/\/cgi\/.*$/, '');
    return base + '/cgi/configserver/cse.cgi?do=b&p=' + encodeURIComponent(dir) + '#new';
}

// ── SELECTION ─────────────────────────────────────────────────────────────────
window.toggleFile = function(path, user, domain, checked) {
    if (checked) State.selected[path] = true;
    else delete State.selected[path];
    updateGroupCheckboxes(user, domain);
    updateBulkButtons();
    updateSelectedCount();
};

window.toggleAllGlobal = function(checked) {
    State.files.forEach(function(f) {
        if (f.candidate) {
            if (checked) State.selected[f.path] = true;
            else delete State.selected[f.path];
        }
    });
    document.querySelectorAll('.row-check').forEach(function(cb) {
        var f = State.files.find(function(x) { return x.path === cb.dataset.path; });
        if (f && f.candidate) cb.checked = checked;
    });
    document.querySelectorAll('.chk-user,.chk-domain').forEach(function(cb) { cb.checked = checked; });
    updateBulkButtons();
    updateSelectedCount();
};

window.toggleUserCandidates = function(user, checked) {
    State.files.forEach(function(f) {
        if (f.user === user && f.candidate) {
            if (checked) State.selected[f.path] = true;
            else delete State.selected[f.path];
        }
    });
    // Sync row checkboxes for this user
    document.querySelectorAll('.row-check').forEach(function(cb) {
        var f = State.files.find(function(x) { return x.path === cb.dataset.path; });
        if (f && f.user === user && f.candidate) cb.checked = checked;
    });
    // Sync domain checkboxes for this user
    document.querySelectorAll('.chk-domain[data-user="' + user + '"]').forEach(function(cb) {
        cb.checked = checked;
    });
    updateBulkButtons();
    updateSelectedCount();
};

window.toggleDomainCandidates = function(user, domain, checked) {
    State.files.forEach(function(f) {
        if (f.user === user && f.domain === domain && f.candidate) {
            if (checked) State.selected[f.path] = true;
            else delete State.selected[f.path];
        }
    });
    document.querySelectorAll('.row-check').forEach(function(cb) {
        var f = State.files.find(function(x) { return x.path === cb.dataset.path; });
        if (f && f.user === user && f.domain === domain && f.candidate) cb.checked = checked;
    });
    updateGroupCheckboxes(user, domain);
    updateBulkButtons();
    updateSelectedCount();
};

function updateGroupCheckboxes(user, domain) {
    // Update domain checkbox
    var domainFiles      = State.files.filter(function(f) { return f.user === user && f.domain === domain && f.candidate; });
    var domainSelected   = domainFiles.filter(function(f) { return State.selected[f.path]; });
    var domChk = document.querySelector('.chk-domain[data-user="' + user + '"][data-domain="' + domain + '"]');
    if (domChk) domChk.checked = domainFiles.length > 0 && domainSelected.length === domainFiles.length;

    // Update user checkbox
    var userFiles    = State.files.filter(function(f) { return f.user === user && f.candidate; });
    var userSelected = userFiles.filter(function(f) { return State.selected[f.path]; });
    var userChk = document.querySelector('.chk-user[data-user="' + user + '"]');
    if (userChk) userChk.checked = userFiles.length > 0 && userSelected.length === userFiles.length;
}

function selectedPaths() { return Object.keys(State.selected); }

function updateBulkButtons() {
    var has = selectedPaths().length > 0;
    document.getElementById('btn-delete-selected').disabled = !has;
}

function updateSelectedCount() {
    document.getElementById('selected-count').textContent = selectedPaths().length;
}

// ── ACTIONS ───────────────────────────────────────────────────────────────────
window.singleDelete = function(path) {
    var filename = path.split('/').pop();
    openModal(
        'Delete Log',
        'Permanently delete <strong>' + esc(filename) + '</strong>?',
        function() { executeDelete([path]); }
    );
};

window.bulkDelete = function() {
    var paths = selectedPaths();
    if (!paths.length) return;
    openModal(
        'Delete ' + paths.length + ' Files',
        'Permanently delete <strong>' + paths.length + '</strong> selected log file(s)? This cannot be undone.',
        function() { executeDelete(paths); }
    );
};

window.deleteAllLegacy = function() {
    var paths = State.files.map(function(f) { return f.path; });
    if (!paths.length) return;
    openModal(
        'Delete ALL ' + paths.length + ' error_log Files',
        '<strong>Warning:</strong> This will permanently delete ALL ' + paths.length + ' error_log files on this server.',
        function() { executeDelete(paths); }
    );
};

function executeDelete(paths) {
    var threshold = parseFloat(document.getElementById('load-threshold').value);
    apiCall('load', {}).then(function(loadData) {
        if (!State.loadOverride && loadData.load_1 > threshold) {
            showLoadWarning(loadData.load_1, threshold);
            return;
        }
        doDelete(paths);
    }).catch(function() { doDelete(paths); });
}

function doDelete(paths) {
    apiCall('delete', { paths: paths, mode: State.mode }).then(function(data) {
        var results = data.results || [];
        var freed   = 0;
        var ok = 0, fail = 0;

        results.forEach(function(r) {
            if (r.success) {
                freed += r.freed || 0;
                ok++;
                delete State.selected[r.path];
                State.files = State.files.filter(function(f) { return f.path !== r.path; });
                logActivity('success', 'Deleted: ' + r.path.split('/').pop() + ' — ' + r.message);
            } else {
                fail++;
                logActivity('error', 'Failed: ' + r.path.split('/').pop() + ' — ' + r.message);
            }
        });

        if (freed > 0) logActivity('info', 'Total freed: ' + formatBytes(freed));
        if (fail > 0)  logActivity('warn', fail + ' operation(s) failed.');

        // Refresh summary and re-render
        var ageDays = parseInt(document.getElementById('age-threshold').value) || 5;
        var cutoff  = Date.now() / 1000 - (ageDays * 86400);
        var users   = {}, domains = {}, total = 0, reclaimable = 0, candidates = 0;
        State.files.forEach(function(f) {
            users[f.user] = domains[f.domain] = 1;
            total += f.size;
            if (f.candidate) { candidates++; reclaimable += f.size; }
        });
        document.getElementById('sum-users').textContent       = Object.keys(users).length;
        document.getElementById('sum-domains').textContent     = Object.keys(domains).length;
        document.getElementById('sum-files').textContent       = State.files.length;
        document.getElementById('sum-candidates').textContent  = candidates;
        document.getElementById('sum-size').textContent        = formatBytes(total);
        document.getElementById('sum-reclaimable').textContent = formatBytes(reclaimable);

        if (State.files.length === 0) {
            document.getElementById('elm-results').style.display = 'none';
            document.getElementById('elm-empty').style.display   = 'block';
        } else {
            renderTable();
            updateBulkButtons();
        }

    }).catch(function(e) {
        logActivity('error', 'Delete failed: ' + e.message);
    });
}

// ── SORT ──────────────────────────────────────────────────────────────────────
window.sortTable = function(col) {
    State.sortDir = (State.sortCol === col && State.sortDir === 'asc') ? 'desc' : 'asc';
    State.sortCol = col;
    renderTable();
};

function sortFiles(files) {
    var col  = State.sortCol;
    var mult = State.sortDir === 'asc' ? 1 : -1;
    return files.slice().sort(function(a, b) {
        switch (col) {
            case 'domain': return mult * a.domain.localeCompare(b.domain);
            case 'path':   return mult * a.path.localeCompare(b.path);
            case 'size':   return mult * (a.size - b.size);
            case 'age':    return mult * (a.age_days - b.age_days);
            default:
                var u = a.user.localeCompare(b.user);
                return u !== 0 ? u : a.domain.localeCompare(b.domain);
        }
    });
}

// ── MODAL ─────────────────────────────────────────────────────────────────────
var _modalCallback = null;

function openModal(title, body, onConfirm) {
    document.getElementById('modal-title').textContent = title;
    document.getElementById('modal-body').innerHTML    = body;
    document.getElementById('elm-modal-overlay').style.display = 'flex';
    _modalCallback = onConfirm;
    document.getElementById('modal-confirm').onclick = function() {
        var cb = _modalCallback;
        closeModal();
        if (cb) cb();
    };
}

window.closeModal = function() {
    document.getElementById('elm-modal-overlay').style.display = 'none';
    _modalCallback = null;
};

// ── ACTIVITY LOG ──────────────────────────────────────────────────────────────
function logActivity(type, message) {
    document.getElementById('elm-activity-section').style.display = 'block';
    var log  = document.getElementById('elm-activity-log');
    var now  = new Date().toLocaleTimeString();
    var line = document.createElement('div');
    line.className = 'elm-activity-line elm-activity-' + type;
    line.innerHTML = '<span class="elm-activity-time">' + now + '</span>' +
                     '<span class="elm-activity-msg">'  + esc(message) + '</span>';
    log.insertBefore(line, log.firstChild);
}

window.clearActivity = function() {
    document.getElementById('elm-activity-log').innerHTML = '';
    document.getElementById('elm-activity-section').style.display = 'none';
};

// ── UI STATE ──────────────────────────────────────────────────────────────────
function showScanning() {
    document.getElementById('elm-scanning').style.display = 'block';
    document.getElementById('elm-results').style.display  = 'none';
    document.getElementById('elm-empty').style.display    = 'none';
    document.getElementById('btn-scan').disabled          = true;
    document.getElementById('btn-scan').textContent       = 'Scanning...';
}

function hideScanning() {
    document.getElementById('elm-scanning').style.display = 'none';
    document.getElementById('btn-scan').disabled          = false;
    document.getElementById('btn-scan').textContent       = 'Scan Logs';
}

function hideResults() {
    document.getElementById('elm-results').style.display = 'none';
    document.getElementById('elm-empty').style.display   = 'none';
    State.files    = [];
    State.selected = {};
}

// ── API ───────────────────────────────────────────────────────────────────────
function apiCall(action, params) {
    var body = new URLSearchParams();
    body.append('action', action);
    Object.keys(params).forEach(function(k) {
        var v = params[k];
        if (Array.isArray(v)) {
            v.forEach(function(item) { body.append(k, item); });
        } else {
            body.append(k, v);
        }
    });
    return fetch(API_URL, { method: 'POST', body: body })
        .then(function(resp) {
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            return resp.json();
        })
        .then(function(data) {
            if (data.error) throw new Error(data.error);
            return data;
        });
}

// ── UTILS ─────────────────────────────────────────────────────────────────────
function esc(str) {
    return String(str)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function formatBytes(bytes) {
    bytes = parseInt(bytes) || 0;
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
    if (bytes >= 1048576)    return (bytes / 1048576).toFixed(2) + ' MB';
    if (bytes >= 1024)       return (bytes / 1024).toFixed(2) + ' KB';
    return bytes + ' B';
}
